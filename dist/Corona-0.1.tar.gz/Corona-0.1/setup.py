from distutils.core import setup

setup(
  name = 'Corona',
  packages = ['Corona'],
  version = '0.1',
  license='MIT',
  description = 'visualization in python with the corona virus world wide data through time line',
  author = 'Yaniv Maimon',
  author_email = 'yanivmaimon18@gmail.com',
  url = 'https://github.com/yanivmm/Corona',
  download_url = 'https://github.com/yanivmm/Corona/archive/v_01.tar.gz',
  keywords = ['vizualization', 'data', 'coronavirus', 'COVID-19', 'Timeline'],
  install_requires=[
          
          'pandas',
          'matplotlib',
          'seaborn',
      ],
  classifiers=[
    'Development Status :: 3 - Alpha',

    'Intended Audience :: Developers',
    'Topic :: Data visualization :: Time line analisys',

    'License :: OSI Approved :: MIT License',

    'Programming Language :: Python :: 3',
    'Programming Language :: Python :: 3.7',
  ],
)