from distutils.core import setup

setup(
  name = 'coronaVisual',
  packages = ['coronaVisual'],
  version = '0.2',
  license='MIT',
  description = 'visualization in python about the corona virus world data through time',
  author = 'Yaniv Maimon',
  author_email = 'yanivmaimon18@gmail.com',
  url = 'https://github.com/yanivmm/Corona',
  download_url = 'https://github.com/yanivmm/coronaVisual/archive/v_02.tar.gz',
  keywords = ['vizualization', 'data', 'coronavirus', 'COVID-19', 'Timeline'],
  install_requires=[

          'pandas',
          'matplotlib',
          'seaborn',
      ],
  classifiers=[
    'Development Status :: 3 - Alpha',

    'Intended Audience :: Developers',
    'Topic :: Data Visualization :: Time Line Analisys',

    'License :: OSI Approved :: MIT License',

    'Programming Language :: Python :: 3',
    'Programming Language :: Python :: 3.7',
  ],
)
